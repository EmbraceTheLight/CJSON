#define DEBUG
#include"Serialization.h"
#include"Unserialization.h"
#include"tests.h"
#ifdef DEBUG
	#include<vld.h>
#endif // DEBUG

int main(void) {
	//test_handle_input();  
	//test_parse_json_string();
	//test_json_find();
	//test_json_addKV();
	//test_json_updateKV();
	//test_json_deleteKV();
	main_menu();
	return 0;
}

